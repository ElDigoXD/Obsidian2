En el caso de que no se tenga cobol instalado es necesario añadir 
la librería libcob.so.4 a /lib/ o a /usr/lib/ para poder ejecutar 
el programa.
